from video import vid
vid()
from login import log
log() 
